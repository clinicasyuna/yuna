# Code Citations

## License: desconhecido
https://github.com/Roman2011Kiber/Roman2011Kiber.github.io/tree/58bb9001be34dfc9f5f334623478d3b56b810238/javascript/add_set_del/index.html

```
src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
     <script src="https://www.gstatic.com/firebasejs/9.23.
```


## License: desconhecido
https://github.com/Stanleycordeiro/finance_Control_System/tree/d87bdceae192c6266641117594860cbb884b00e5/pages/home/home.html

```
.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
     <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"
```


## License: desconhecido
https://github.com/MetaMindsJen/MetaMindsApp/tree/01eda621a7ecc14f654f139d450da7a67f673f75/blogmain.html

```
.js"></script>
     <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
     <script src="https://www.
```


## License: desconhecido
https://github.com/MetaMindsJen/metamindsjen.github.io/tree/ed252913c89123054cca46a3360c27c91b886961/blogmain.html

```
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
     <script src="https://www.gstatic.com/firebasejs/9.
```

