// Configuração segura do Firebase para deploy
const firebaseConfig = {
  apiKey: "AIzaSyAogGkN5N24Puss4-kF9Z6npPYyEzVei3M",
  authDomain: "studio-5526632052-23813.firebaseapp.com",
  projectId: "studio-5526632052-23813",
  storageBucket: "studio-5526632052-23813.firebasestorage.app",
  messagingSenderId: "251931417472",
  appId: "1:251931417472:web:4b955052a184d114f57f65"
};
export default firebaseConfig;
